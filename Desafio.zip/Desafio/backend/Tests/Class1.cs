﻿using System;

namespace Tests
{
    public class Class1
    {
    }
}
