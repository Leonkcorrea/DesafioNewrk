﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tests.Services
{
    public class BookServiceTest
    {
        private BookService bookService;
        public BookService
    }
}
