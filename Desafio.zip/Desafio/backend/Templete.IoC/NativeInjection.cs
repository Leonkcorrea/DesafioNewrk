﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace Templete.IoC
{
    public static  class NativeInjection
    {
        public static void RegistarServices(IServiceCollection services) {

            services.AddScoped(IBookService, BookService);



            }

    }
}
