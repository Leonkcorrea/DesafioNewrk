﻿using Dapper;
using Microsoft.Data.Sqlite;
using Neowrk.Library.Core.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Neowrk.Library.Repository
{
    public class BookRepository : BaseRepository
    {
      
        public BookRepository(string connectionString)
        : base(connectionString) { }

        public async Task<List<Book>> GetAllBooks()
        {
            using IDbConnection dbConnection = new SqlConnection(_connectionString);

            string query = @"SELECT Id, Title, Author, Publisher, BookCategoryId 
                             FROM Book
                             WHERE LentToStudentId IS NULL";

            return (await dbConnection.QueryAsync<Book>(query)).AsList();
        }
        public async Task<Book> SelectBook(Guid id)
        {
            using IDbConnection dbConnection = new SqlConnection(_connectionString);

            string query = $"Select Book From Books WHERE Id = {id}";
            return (await dbConnection.QueryAsync<Book>(query)).FirstOrDefault();
        }

        public async Task BorrowBook(Guid id, string studentEmail)
        {
            using IDbConnection dbConnection = new SqlConnection(_connectionString);

            string query = "UPDATE Book SET LentToStudentId = (SELECT TOP 1 Id FROM Student WHERE Email = @StudentEmail) WHERE Id = @BookId";
            await dbConnection.ExecuteAsync(query,
                new
                {
                    @StudentEmail = studentEmail,
                    @BookId = id
                });
        }
    }
}
