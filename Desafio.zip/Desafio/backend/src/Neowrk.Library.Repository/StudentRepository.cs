﻿using Dapper;
using Neowrk.Library.Core.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neowrk.Library.Repository
{
    public class StudentRepository : BaseRepository
    {
        public StudentRepository(string connectionString) : base(connectionString)
        {


        }
        public async Task<Student> SelectStudent(string studentEmail)
        {
            using IDbConnection dbConnection = new SqlConnection(_connectionString);

            string query = $"Select Student From Students WHERE Email = {studentEmail}";

            return (await dbConnection.QueryAsync<Student>(query)).FirstOrDefault();
        }
    }
}
