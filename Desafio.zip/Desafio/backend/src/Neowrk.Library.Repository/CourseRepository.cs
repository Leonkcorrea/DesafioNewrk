﻿using Dapper;
using Neowrk.Library.Core.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neowrk.Library.Repository
{
    public class CourseRepository : BaseRepository
    {
        public CourseRepository(string connectionString) : base(connectionString)
        {
        }
        public async Task<Course> SelectCourse(Guid id)
        {
            using IDbConnection dbConnection = new SqlConnection(_connectionString);

            string query = $"Select Course From Books Course Id = {id}";

            return (await dbConnection.QueryAsync<Course>(query)).FirstOrDefault();
        }
    }
}
