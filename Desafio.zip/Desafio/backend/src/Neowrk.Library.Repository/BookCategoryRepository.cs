﻿using Dapper;
using Neowrk.Library.Core.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace Neowrk.Library.Repository
{
    public class BookCategoryRepository : BaseRepository
    {
        public BookCategoryRepository(string connectionString) : base(connectionString)
        {
        }
    }
}
