﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Neowrk.Library.Repository
{
    public abstract class BaseRepository
    {
        protected readonly string _connectionString;

        public BaseRepository(string connectionString)
        {
            this._connectionString = connectionString;
        }        
    }
}
