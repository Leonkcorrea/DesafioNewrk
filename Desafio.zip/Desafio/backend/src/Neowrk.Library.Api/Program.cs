using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Neowrk.Library.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace Neowrk.Library.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {            
            var host = CreateHostBuilder(args).Build();

            IConfiguration configs = host.Services.GetService<IConfiguration>();

            if (args.Contains("seed"))
            {
                DatabaseBootstrap bookRepository = new DatabaseBootstrap(configs.GetConnectionString("Master"));
                bookRepository.Setup().Wait();
            }

            host.Run(); 
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
