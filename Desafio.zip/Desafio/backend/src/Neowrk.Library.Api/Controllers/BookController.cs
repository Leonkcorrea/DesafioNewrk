﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Neowrk.Library.Api.ViewModels;
using Neowrk.Library.Core.Models;
using Neowrk.Library.Service;
using Neowrk.Library.Service.Interfaces;

namespace Neowrk.Library.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BookController : ControllerBase
    {
        private readonly ILogger<BookController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IBookService _bookService;

        public BookController(ILogger<BookController> logger,
            IConfiguration configuration, IBookService bookService)
        {
            _logger = logger;
            this._configuration = configuration;
            _bookService = bookService;
        }


        [HttpGet]
        [Route("/api/books")]
        public async Task<IActionResult> Get()
        {

            List<Book> books = await _bookService.GetAllBooks(_configuration);

            return Ok(books.Select(b => new BookViewModel()
            {
                Author = b.Author,
                Id = b.Id,
                Pages = b.Pages,
                Publisher = b.Publisher,
                Title = b.Title
            }));
        }

        [HttpPost]
        [Route("/api/books/{bookId:guid}/student/{studentEmail}")]
        public async Task<IActionResult> Post([FromRoute] Guid bookId, [FromRoute] string studentEmail, [FromQuery] string action)
        {
            if (String.IsNullOrWhiteSpace(studentEmail))
            {
                return BadRequest("User email cannot be empty");
            }

            switch (action)
            {
                case "borrow":
                    await _bookService.BorrowBook(_configuration, bookId, studentEmail);
                    break;
                default:
                    return NotFound("Invalid action");
            }

            return Ok();
        }
    }
}
