﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Google.Apis.Auth;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace Neowrk.Library.Api.Controllers
{
    [ApiController]
    [Route("auth")]
    public class GoogleAuthController : ControllerBase
    {
        private readonly ILogger<BookController> _logger;
        public GoogleAuthController(ILogger<BookController> logger)
        {
            _logger = logger;
        }
        [HttpPost]
        [AllowAnonymous]
        [Route("test/{token}")]
        public async Task<IActionResult> Test([FromRoute] string token)
        {
            try
            {
                var googleUSer = await GoogleJsonWebSignature.ValidateAsync(token, new GoogleJsonWebSignature.ValidationSettings()
                {
                    Audience = new[] { "359020175538-oqos2e534hpo2kg68hpj6av0gl3uuobk.apps.googleusercontent.com" }
                });
                return Ok();
            }
            catch (Exception exception)
            {
                return BadRequest(exception);

            }
        }
    }
}
