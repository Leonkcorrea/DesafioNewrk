﻿using Microsoft.Extensions.Configuration;
using Neowrk.Library.Core.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Neowrk.Library.Service.Interfaces
{
  public interface IBookService
    {
        Task BorrowBook(IConfiguration configuration,Guid id, string studentEmail);
        Task<List<Book>> GetAllBooks(IConfiguration configuration);
    }
}
