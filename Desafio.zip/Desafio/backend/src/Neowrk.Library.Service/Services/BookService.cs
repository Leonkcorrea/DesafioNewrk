﻿using Microsoft.Extensions.Configuration;
using Neowrk.Library.Core.Models;
using Neowrk.Library.Repository;
using Neowrk.Library.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Neowrk.Library.Service
{
    public class BookService : IBookService
    {
        


        public async Task<List<Book>> GetAllBooks(IConfiguration configuration)
        {
            var _connectionString = configuration.GetConnectionString("DefaultConnection");
            var bookRepository = new BookRepository(_connectionString);
            return await bookRepository.GetAllBooks();
        }

        public async Task BorrowBook(IConfiguration configuration, Guid id, string studentEmail)
        {
            var _connectionString = configuration.GetConnectionString("DefaultConnection");
            var studentRepository = new StudentRepository(_connectionString);
            var bookRepository = new BookRepository(_connectionString);
            Book book = await bookRepository.SelectBook(id);
            Student student = await studentRepository.SelectStudent(studentEmail);
            Course course = await new CourseRepository(_connectionString).SelectCourse(student.CourseId);
            List<string> listaGuids = new List<string>();
            foreach(Guid guid in course.CategoriesOfBooksIds)
            {
                listaGuids.Add(guid.ToString());
            }
            if (listaGuids.Contains(book.BookCategoryId.ToString()))
            {
                await bookRepository.BorrowBook(id, studentEmail);
            }
            else
            {
                throw new Exception("Você não pode pegar esse livro emprestado, pois não está na categoria do seu curso :( ");
            }
        }
    }
}
