﻿
using Microsoft.Extensions.Configuration;
using Moq;
using Neowrk.Library.Core.Models;
using Neowrk.Library.Repository;
using Neowrk.Library.Service;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Neowrk.Library.Core.Tests
{
    public class BookServiceTest
    {
        private BookService bookService;
        public BookServiceTest()
        {
            IConfiguration configuration = null;
            using IDbConnection dbConnection = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
            bookService = new BookService();
        }
        [Fact]
        public async void GetAll()
        {
            IConfiguration configuration = null;
            await bookService.GetAllBooks(configuration);
            Assert.True(true);
        }
        [Fact]
        public async void BorrowBooks()
        {
            IConfiguration configuration = null;
            await bookService.BorrowBook(configuration, Guid.NewGuid(), "huguinho@domain.com");
            Assert.True(true);
        }

    }
}
