﻿using Microsoft.Extensions.DependencyInjection;
using Neowrk.Library.Service;
using Neowrk.Library.Service.Interfaces;
using System;

namespace Templete.IoC
{
    public static  class NativeInjection
    {
        public static void RegistarServices(IServiceCollection services) {

            services.AddScoped<IBookService, BookService>();



            }

    }
}
