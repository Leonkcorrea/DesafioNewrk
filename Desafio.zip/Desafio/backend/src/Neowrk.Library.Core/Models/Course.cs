﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neowrk.Library.Core.Models
{
    public class Course
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<Guid> CategoriesOfBooksIds { get; set; }
    }
}
