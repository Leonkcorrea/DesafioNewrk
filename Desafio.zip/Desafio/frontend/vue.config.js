module.exports = {
  "lintOnSave": false,
  "transpileDependencies": [
    "vuetify"
  ]
}