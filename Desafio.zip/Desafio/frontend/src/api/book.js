import axios from 'axios'
import Axios from 'axios'



export default {
    async listBooks(){        
        return axios.get('api/books');       
    },
    async borrowBook(id) {
        var user = JSON.parse(localStorage.getItem('loggedUser'));
        return axios.post(`/api/books/${id}/student/${user.email}?action=borrow`);
    }
}