# Neowrk Assessment

Boas vindas à biblioteca da neowrk. Esse projeto tem como objetivo controlar o empréstimo de livros de uma biblioteca fictícia.

Esse projeto ainda está em sua fase inicial de desenvolvimento e precisamos da sua ajuda para termos um sistema bem legal no fim.

Algumas funcionalidades já estão presentes, são elas:
* Login
* Listagem de livros
* Pegar emprestado

Muitas melhorias ainda precisam ser feitas para essas funcionalidades ficarem estáveis, não se preocupe, abaixo tem a lista de coisas que planejamos para essa iteração:

* Perceba que o código no backend não está utilizando nenhum tipo de injeção de dependência. Nessa iteração devemos alterar pra usar injeção ao invés de ficar fazendo new nas classes ali.

* Perceba que nossas api's não estão protegidas por nenhum mecanismo de autenticação. 
    * O frontend já possui autenticação com o google, porém o idToken (que está sendo salvo no localStorage) não é repassado para o backend. 
    * Precisaremos repassar esse idToken pro backend e utilizar a autenticação do google para validar esse token
    * Você pode usar os seguintes dados pro oauth (não se preocupe, esse client será apagado logo logo):
        * ClientId: 359020175538-oqos2e534hpo2kg68hpj6av0gl3uuobk.apps.googleusercontent.com
        * ClientSecret: X37RlAtJDLs18qH5TnxQ3x5E

* Além desses itens técnicos, precisaremos implementar a seguinte regra de negócio:
    * Para evitar que alunos fiquem pegando livros emprestados para amigos pessoais, temos que implementar a seguinte regra: Quando um aluno pegar um livro emprestado, devemos validar se a categoria do livro está ligada ao curso que ele está fazendo, caso não haja nenhuma ligação devemos exibir uma mensagem de erro na tela.

* Como agora temos uma regra mais complexa no sistema, precisaremos incluir pelo menos um teste de unidade pra ela, certo? Inclua um projeto de testes no backend da aplicação e utilize algum mecanismo de mock (sugiro utilizar a lib Moq) para simular as chamadas ao banco de dados.


Com todos esses requisitos, mãos a obra!!! Utilize esse repositório para fazer o clone e o push do seu código.

Sugiro você dar uma olhada no código antes, tente entender como as coisas estão organizadas. Você pode utilizar a ferramenta que quiser para codificar, mas sugerimos utilizar o vscode ou o visual studio.

**Melhorias na qualidade do código são muito bem vindas, sinta-se a vontade para alterar qualquer ponto sistema**

Muito obrigado por participar do processo!


## Ferramentas
Para rodar esse projeto você vai precisar:

1. .Net core sdk 3.1 (https://dotnet.microsoft.com/download)

1. MSSql LocalDb - (https://download.microsoft.com/download/7/c/1/7c14e92e-bdcb-4f89-b7cf-93543e7112d1/SqlLocalDB.msi)

1. NodeJs (https://nodejs.org/en/download/)

Com todas essas ferramentas instaladas, basta executar os seguintes comandos no terminal do seu sistema operacional:

### Backend:

```
dotnet run --project .\backend\src\Neowrk.Library.Api\Neowrk.Library.Api.csproj -- seed
```
Esse comando irá executar o site na url "https://localhost:5001" e o banco de dados já será criado com alguns dados já inseridos. Você pode verificar os dados inseridos no arquivo **DatabaseBoostrp.cs**. É recomendado você utilizar o seu e-mail nos registros da tabela Student.

**Obs.: Toda vez que vc executar esse comando os dados das tabelas serão apagados. Para não apagar os dados é só tirar o argumento "-- seed"**

### Frontend:

```
cd frontend
npm install
npm run serve
```

Esse comando irá executar o frontend na url "http://localhost:8080"



